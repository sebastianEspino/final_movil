import { Component } from '@angular/core'

@Component({
  selector: 'adso',
  template: "<page-router-outlet></page-router-outlet>",
})
export class AppComponent {}
