import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ApiService {

    apiUrl = 'http://10.171.68.189:8000/api/1.0/'; // Replace with your registration endpoint URL

    constructor(private http: HttpClient) {}

    registrarse(post: any): Observable<any> {
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Token 4037c215af5aad52224d29fe6bbc1f8dc2ad0971'
        });

        return this.http.post<any>(`${this.apiUrl}Usuarios/`, post, { headers });
    }

   

    
}

