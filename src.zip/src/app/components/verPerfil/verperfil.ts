import { Router } from "@angular/router";
import { Component, OnInit } from '@angular/core'
import { Page } from "@nativescript/core";
import { ApiService } from './api.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'verperfil',
  templateUrl: './verperfil.html',
  styleUrls: ['./verperfil.css']
})
export class VerPerfilComponent implements OnInit {
  id:number;
  details: any;
  public constructor(private router: Router, private page: Page, private activatedRoute: ActivatedRoute,private apiService: ApiService) {
    // Use the component constructor to inject providers.
    this.obtenerDetails();
  
    }

    public obtenerDetails(){
      this.activatedRoute.queryParams
          .subscribe((params) => {
            this.apiService.getRegisterById(params.id).subscribe((data: any[]) => {
              console.log(data);
              this.details = data;
          });
          }
        );
      
    }
  
  ngOnInit(): void {
    this.page.actionBarHidden = true;
  }
  public onTap() {
  }
  public perfil(){
    this.router.navigate(["verperfil"])
  }
  public productos(){
    this.router.navigate(["productos"])
  }
  public cerrar_sesion(){
    this.router.navigate(["login"])
  }
}  